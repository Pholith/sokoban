# -*- coding: utf-8 -*-

from random import randint

#.................................................................................#
#fonctions génériques
def retournerIndex(i, j,largeurFenetre, hauteurFenetre):
    #Récupère des coordonnées et renvoie les index de la liste correspondants
    X = 0
    for x in range(0,largeurFenetre,largeurCase):
        if x <= i and i <= x + largeurCase:
            indexColonne = X
            break
        X += 1
    Y = 0
    for y in range(0,hauteurFenetre,largeurCase):
        if y <= j and j <= y + largeurCase:
            indexLigne = Y
            break
        Y += 1
    return(indexLigne,indexColonne)
    
def retournerCoordonnees(i, j):
    #Récupère les positions i et j de la carte 2D du jeu et la largeur des cases et renvoie les coordonnées supérieures à gauche de la case correspondante
    return(j * largeurCase, i * largeurCase)

def partieGagnee(carte):
    """
    >>> partieGagnee([['W','W','W','W'],['W','W','.','W']])
    True
    >>> partieGagnee([['T','W','W','W'],['W','W','.','W']])
    False
    >>> partieGagnee([['.','W','W','W'],['W','T','.','W']])
    False
    """
    #Renvoie True si la partie est gagnée
    for i in range(len(carte)): #i les lignes
        for j in range(len(carte[i])): #j les colonnes
            if carte[i][j] in {"T", "TJ", "KB"}: #Si on ne trouve pas de target de ce type dans la carte, c'est gagné.
                return False
    return True
    
def estVide(i, j, carte):
    #Reçoit des coordonnées et renvoie True si la case est vide
    """
    >>> estVide(1,0, [['W','W','W','W'],['.','W','W','W'],['W','W','W','W']])
    True
    >>> estVide(1,2, [['W','W','W','W'],['W','W','.','W']])
    True
    >>> estVide(1,1, [['W','W','W','W'],['W','W','.','W']])
    False
    """
    if estQuoi(i, j, carte) == '.':
        return(True)
    return(False)

def estQuoi(i, j, carte):#i ligne et j colonne
    """
    >>> estQuoi(1,0, [[0,1,2,3],[4,5,6,7],[8,9,10,11]])
    4
    >>> estQuoi(2,1, [[0,1,2,3],[4,5,6,7],[8,9,10,11]])
    9
    """
    #Renvoie en caractère le nom de l'objet dans la case
    return(carte[i][j])

def indexJoueur(carte):
    #Renvoie la position du joueur dans la carte
    """
    >>> indexJoueur([['W','S','W','W'],['W','W','.','W']])
    (0, 1)
    >>> indexJoueur([['W','T','J','W'],['W','W','.','W']])
    (0, 2)
    >>> indexJoueur([['W','T','.','W'],['W','W','.','W']])
    Traceback (most recent call last):
    AssertionError
    """
    for i in range(len(carte)): #i les lignes
        for j in range(len(carte[i])): #j les colonnes
            if carte[i][j] in {"J","S","TJ"}: #Si le joueur est sur la case de départ
                return(i, j)
    assert() #Erreur: il n'y a plus de joueur

def largeurDeCase(largeurFenetre, hauteurFenetre, carte):
    """
    >>> largeurDeCase(300,300,[[0,1,2],[3,4,5],[6,7,8]])
    100
    """
    #Fonction qui renvoie la largeur d'une case
    nbrDeCase = len(carte[0])
    #100 est la largeur de l'inventaire
    return((largeurFenetre-100)//nbrDeCase)