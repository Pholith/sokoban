README.txt

Vincent BUISSET / Ewen BOUQUET
------------- Avancement --------------
La partie 1 est finie.
La partie 2 est finie.
Une premi�re extension a �t� impl�ment�e: on peut tirer les caisses avec la touche e + fl�ches.

---------- Organisation --------------
Notre programme est organis� en plusieurs fichiers, le fichier contenant le programme principal et l'affichage principal, un fichier pour les fonctions de dessinage du contenu, un pour les d�placements et leurs actions, un fichier qui contient la globalit� des fonctions auxiliaires et enfin un fichier pour la lecture de la map.

---------- Choix techniques ------------
Pour la structure de la map, nous avons choisi de mettre les lettres contenant l'objet de la case dans une matrice (au format listes de liste). A chaque d�placement, on modifie la map et on appelle la fonction affichage qui met � jour l'affichage par rapports aux lettres stock�es dans la map.

Pour le stockage des clefs et des d�placements dans la partie 2, nous avons cr�� un inventaire sous forme de dictionnaire plut�t qu'une liste pour pouvoir r�cup�rer l'information sans conna�tre l'indice et le contenu de chaque case.

La boucle principale du projet est organis� comme ceci: tant que le joueur n'est pas gagn�, on attends un �v�nement au clavier valide puis on effectue l'action correspondante (ex: modification de la map, rechargement de la partie, etc.) puis on mets � jour l'affichage � l'�cran. La fonction d�bug est un cas particulier, fonctionnant de mani�re ind�pendante des fonctions principales de mouvement (sauf activation).

Les seules modules utilis�s sont: doctest, math et random.

Par choix d'organisation et de praticit�, nous avons utilis� un git.

-------- Probl�mes rencontr�s ----------
Notre probl�me principal a �t� des erreurs d'importation de nos autres fichiers, les fichiers s'importaient les uns les autres et certaines fonctions devenaient inutilisables car "non d�finies". Nous avons donc rassembl� certaines fonctions et cr�� un fichier fonction.py pour �viter d'avoir plus de probl�mes.

------- Touches sp�ciales ---------------
S: Touche de sauvegarde
R: Touche qui permet de relancer la partie pr�cedamment enregistr�e
D: Touche qui active le mode debug
E: Touche de s�lection de caisse pour la tirer

------ Codage des cases en fonction de leur contenu ------
Nous avons rajout� des "types" de case pour pouvoir g�rer les �l�ments par dessus les autres.
".":Case vide
"W":Wall
"T":Target
"S":Start
"D":Door
"K":Key
"B":Box
"TB":Box On a target
"TJ":Joueur On a target
"SJ":Joueur On start
"J": Joueur