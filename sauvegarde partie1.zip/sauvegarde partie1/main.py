# -*- coding: utf-8 -*-

import upemtk as tk
import doctest
import math
import time
from dessiner import *
from deplacement import *
from fonctions import *

def recharger():
    #Permet de relancer la partie à l'appui de la touche r
    return [
    [".",".","T",".",".","W",".",".",".",".","."],
    ["W",".","B",".",".","W",".",".",".",".","."],
    ["W",".",".",".",".","W",".",".",".",".","."],
    ["W",".",".",".",".","W",".",".",".",".","."],
    ["W",".",".",".",".",".",".",".",".",".","."],
    ["W",".",".",".",".","W",".","S",".",".","."],
    ["W",".",".",".",".","W",".",".",".",".","."],
    ["W",".",".",".",".","W",".",".",".",".","."],
    ["W",".",".",".",".","W",".",".",".",".","W"]
    ]

def generationFenetre(liste):
    #Ouverture la fenêtre, sa taille dépend du nombre de case
    nbrDeLigne = len(liste)
    nbrDeColonne = len(liste[0])
    largeurCase = 50
    fenetre_largeur = nbrDeColonne * largeurCase
    fenetre_hauteur = nbrDeLigne * largeurCase
    return(fenetre_largeur, fenetre_hauteur)

def affichage(largeurFenetre, hauteurFenetre, liste):
    #On met à jour la fenêtre et on affiche chaque élément
    tk.efface_tout()
    largeurCase = largeurDeCase(largeurFenetre, hauteurFenetre, liste)
    #On parcourt la liste 2D (des sous listes dans une liste)
    dessinerQuadrillage(largeurFenetre, hauteurFenetre, liste)
    for i in range(len(liste)): #i les lignes
        for j in range(len(liste[i])): #j les colonnes

            if liste[i][j] == ".":#Case vide
                pass
            elif liste[i][j] == "W":#Wall
                dessinerMur(j*largeurCase, i*largeurCase, largeurCase)
            elif liste[i][j] == "T":#Target
                dessinerCible(j*largeurCase, i*largeurCase, largeurCase)
            elif liste[i][j] == "S":#Start
                dessinerJoueur(j*largeurCase, i*largeurCase, largeurCase)
            elif liste[i][j] == "B":#Box
                dessinerBoite(j*largeurCase, i*largeurCase, largeurCase)
            elif liste[i][j] == "TB":#Box On a target
                dessinerCible(j*largeurCase, i*largeurCase, largeurCase)
                dessinerBoite(j*largeurCase, i*largeurCase, largeurCase)
            elif liste[i][j] == "TJ":#Joueur On a target
                dessinerCible(j*largeurCase, i*largeurCase, largeurCase)
                dessinerJoueur(j*largeurCase, i*largeurCase, largeurCase)
            elif liste[i][j] == "J":#Joueur
                dessinerJoueur(j*largeurCase, i*largeurCase, largeurCase)

    tk.mise_a_jour()

def main():
    #Fonction principale du programme

    #---------- Initialisation ----------
    carte = recharger()
    largeurFenetre, hauteurFenetre = generationFenetre(carte)
    infoCarte = [largeurFenetre, hauteurFenetre] #Stockage des infos dans une liste pour limiter le nombre de paramètres envoyés aux fonctions
    tk.cree_fenetre(largeurFenetre, hauteurFenetre)
    #-------- Fin initialisation --------

    while True:
        affichage(largeurFenetre, hauteurFenetre, carte) #Afficher la carte à l'écran
        if partieGagnee(carte):# Les actions après que la partie soit gagnée
            dessinerVictoire(largeurFenetre,hauteurFenetre)
            tk.attente_clic()
            break
        typeEvent = attenteMouvement(carte, infoCarte) #Récupérer le type de la touche
        if typeEvent == "r":#commande de reset
            carte = recharger()
            continue
        else:
            carte = typeMouvement(typeEvent, carte, infoCarte) #Modifications de la carte par rapport à la touche
    tk.ferme_fenetre()


if __name__ == '__main__':
    main()
    #print(doctest.testmod()) #Pour tester toutes les fonctions