# -*- coding: utf-8 -*-

import upemtk as tk
from fonctions import *
from random import randint
from main import affichage

def attenteMouvement(liste, infoCarte):
    #Attendre une touche de type flèche au clavier ou 0 (mode débug) ou 1 (sélection d'une box à tirer)
    while True:
        event = tk.donne_evenement() #Récupérer un évènement
        typeEvent = tk.type_evenement(event) #Récupérer son type
        if typeEvent == 'Touche': #S'il est de type "touche"
            typeEvent = tk.touche(event) #Récupérer la touche utilisée
            if typeEvent in {"Left", "Right", "Up", "Down", "d", "r"}:
                break
        tk.mise_a_jour() #Mettre à jour les évènements
    return typeEvent #Retourner la touche

def debugDeplacement(liste, infoCarte):
    #Fonction qui nous permet d'effectuer le déplacement aléatoire du joueur de manière automatique
    largeurFenetre, hauteurFenetre = infoCarte[0], infoCarte[1] #Affectations pour plus de clarté
    while True:
        nb = randint(1,4) #Génération d'un entier entre 1 et 4 qui va engendrer un mouvement aléatoire du joueur
        if nb == 1:
            liste = mouvement(0,-1,liste) #Gauche
        elif nb == 2:
            liste = mouvement(0,1,liste) #Droite
        elif nb == 3:
            liste = mouvement(-1,0,liste) #Haut
        elif nb == 4:
            liste = mouvement(1,0,liste) #Bas
        affichage(largeurFenetre, hauteurFenetre, liste) #Afficher la carte à l'écran
        event = tk.donne_evenement() #Récupérer un évènement
        typeEvent = tk.type_evenement(event) #Récupérer son type
        if typeEvent == 'Touche': #Si c'est une touche, ...
            typeEvent = tk.touche(event) #Récupérer la touche
            if typeEvent == "d": #Si la touche est 0, fin de boucle
                break
        if partieGagnee(liste):
            break
        tk.mise_a_jour() #Mise à jour de l'évènement
    return liste

def typeMouvement(typeEvent, liste, infoCarte):
    #Faire bouger le joueur selon la touche qu'il a utilisé ou encore ouvre le mode débug
    if typeEvent == "Left": #Gauche
        liste = mouvement(0,- 1, liste)
    elif typeEvent == "Right": #Droite
        liste = mouvement(0, 1, liste)
    elif typeEvent == "Up": #Haut
        liste = mouvement(-1, 0, liste)
    elif typeEvent == "Down": #Bas
        liste = mouvement(1, 0, liste)
    elif typeEvent == "d": #Débug
        liste = debugDeplacement(liste, infoCarte)
    return liste

def mouvement(cst_i, cst_j, liste):
    #Si le mouvement "basique" du joueur est possible, alors effectuer les modifications sur la carte
    i,j = indexJoueur(liste) #Stocker l'index du joueur
    if 0 <= i + cst_i and i + cst_i < len(liste) and 0 <= j + cst_j and j + cst_j < len(liste[i]): #Ne pas sortir de la carte
        case = estQuoi(i + cst_i, j + cst_j, liste)
        if case in {'.', 'T', 'S'}: #Si il est possible d'avancer
            #Gestion de la case où le joueur va
            if case == 'T': #Si c'est un target
                liste[i + cst_i][j + cst_j] = 'TJ' #La case devient un player on a target
            else:
                liste[i + cst_i][j + cst_j] = 'J' #La case devient un joueur
            #Gestion de case où le joueur était
            if liste[i][j] == 'TJ': #Si c'est une player on a target, ...
                liste[i][j] = 'T' #La case devient un target
            else:
                liste[i][j] = '.' #Sinon, la case devient un vide
        elif case in {'B','TB'}: #Si c'est une boîte
            if estDeplacable(i + 2 * cst_i,j + 2 * cst_j, liste): #Si la case située derrière la caisse à l'opposé du joueur rends possible un déplacement
                liste = deplacerCaisse(i + cst_i, j + cst_j, i + 2 * cst_i, j + 2 * cst_j, liste) #Modifier la carte
    return liste

def deplacerCaisse(avant_i, avant_j, apres_i, apres_j, liste):
    #Permet de pousser une caisse
    i, j = indexJoueur(liste) #Socker l'index du joueur
    #Gestion de la case où était le joueur
    if liste[i][j] == 'TJ': #Si le joueur est sur un target, ...
        liste[i][j] = 'T' #La case devient un joueur
    else:
        liste[i][j] = '.' #Sinon, la case devient vide
    #Gestion de la case ou était la box
    case = liste[avant_i][avant_j]
    if case == 'TB': #Si la box était sur un target, ...
        liste[avant_i][avant_j] = 'TJ' #La case devient un joueur on a target
    else:
        liste[avant_i][avant_j] = "J" #La case devient un joueur
    #Gestion de la case ou la boîte va aller
    case = liste[apres_i][apres_j]
    if case == 'T': #Si c'est un target, ...
        liste[apres_i][apres_j] = 'TB' #La case devient une box on a target
    else:
        liste[apres_i][apres_j] = 'B' #Sinon, la case devient une box "classique"
    return liste

def estDeplacable(i, j, liste):
    #Renvoie True s'il n'y a rien derrière la caisse à l'opposé du joueur
    #i et j sont les cordonnées de cette caisse
    if 0 <= i and i < len(liste) and 0 <= j and j < len(liste[i]): #Ne pas sortir de la carte
        if estQuoi(i, j, liste) in {'.', 'T'}: #Si la case où avancer est vide ou il y a un target
            return True
    return False

if __name__ == '__main__':
    pass
    #print(doctest.testmod()) #Pour tester toutes les fonctions